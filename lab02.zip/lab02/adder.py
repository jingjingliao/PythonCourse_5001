def main():
    first_value = int(input("Enter a first value: "))
    second_value = int(input("Enter a second value: "))

    sum_value = first_value + second_value

    print("The sum of {} + {} is {}".format(first_value, second_value, sum_value))


main()
