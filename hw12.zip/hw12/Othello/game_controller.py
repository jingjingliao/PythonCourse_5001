from disk import Disk


class GameController:
    def __init__(self, DIMENSION, GRID_LEN):
        self.dimension = DIMENSION
        self.grid_len = GRID_LEN
        self.space = self.dimension // self.grid_len
        self.grid = [[None] * self.space for _ in range(self.space)]
        self.directions = ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, 1), (1, -1), (-1, -1), (1, 1))
        self.next_step_map = dict()

    def is_in_boundary(self, i, j):
        if 0 <= i <= len(self.grid) - 1 and 0 <= j <= len(self.grid[0]) - 1:
            return True
        else:
            return False

    def check_legal_space(self, color):
        if color == 0:
            opposite_color = 255
        else:
            opposite_color = 0

        self.next_step_map = dict()

        for i, row in enumerate(self.grid):
            for j, disk in enumerate(row):
                if disk is not None and disk.color == color:
                    for direction in self.directions:
                        path = set()
                        has_opponent = False
                        temp_i = i + direction[0]
                        temp_j = j + direction[1]
                        while self.is_in_boundary(temp_i, temp_j) and self.grid[temp_i][temp_j] is not None and self.grid[temp_i][temp_j].color == opposite_color:
                            has_opponent = True
                            path.add((temp_i, temp_j))
                            temp_i += direction[0]
                            temp_j += direction[1]
                        
                        if self.is_in_boundary(temp_i, temp_j) and self.grid[temp_i][temp_j] is None and has_opponent:
                            existing = self.next_step_map.get((temp_i, temp_j))
                            if existing:
                                self.next_step_map[(temp_i, temp_j)] = existing.union(path)
                            else:
                                self.next_step_map[(temp_i, temp_j)] = path

    def flipover(self, disk_x, disk_y, color):
        flip_list = list(self.next_step_map[(disk_x, disk_y)])
        for location in flip_set:
            self.grid[location[0]][location[1]].change_color(color)

    # def show_legal_space(self):
    #     for next in self.next_step_map:
    #         strokeWeight(0.5)
    #         fill(1, 100, 0)
    #         ellipse(next[0] * 100 + 50, next[1] * 100 + 50, 90, 90)

    # def delete_legal_space(self):
    #     for next in self.next_step_map:
    #         noStroke()
    #         fill(1, 100, 0)
    #         ellipse(next[0] * 100 + 50, next[1] * 100 + 50, 94, 94)
    #         stroke(0)

    # def show_result(self):
    #     if self.available_space == 0:
    #         if self.black_count > self.white_count:
    #             print("Black disk wins")
    #         elif self.black_count < self.white_count:
    #             print("White disk wins")
    #         else:
    #             print("They are equal")


    def is_in_next_step(self, x, y):
        return (x, y) in self.next_step_map
