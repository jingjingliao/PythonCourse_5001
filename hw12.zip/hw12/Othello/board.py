from disk import Disk
from game_controller import GameController


class Board:
    def __init__(self, DIMENSION, GRID_LEN):
        self.dimension = DIMENSION
        self.grid_len = GRID_LEN
        self.space = self.dimension // self.grid_len
        self.start_point = 0
        self.middle = self.dimension // 200
        self.start_hori_line = 0
        self.start_verti_line = 0
        self.end_hori_line = 0
        self.end_verti_line = 0
        self.color = 0
        self.gc = GameController(self.dimension, self.grid_len)
        self.initial_disk()

    def display(self):
        """Draw a board"""
        for _ in range(self.space):
            self.start_hori_line += self.grid_len
            self.end_hori_line += self.grid_len

            self.start_verti_line += self.grid_len
            self.end_verti_line += self.grid_len

            strokeWeight(2)
            line(self.start_point, self.start_hori_line, self.dimension, self.end_hori_line)
            line(self.start_verti_line, self.start_point, self.end_verti_line, self.dimension)

        for i in range(self.space):
            for j in range(self.space):
                if self.gc.grid[i][j] is not None:
                    self.gc.grid[i][j].draw_disk()

    def initial_disk(self):
        """Initialize the first four disks"""
        for i in range(2):
            for j in range(2):
                color = 255
                if (i + j) % 2 == 1:
                    color = 0
                self.gc.grid[self.middle - i][self.middle - j] = Disk(self.middle - i, self.middle - j, color)

    def draw_disk(self, location_x, location_y):
        if self.gc.is_in_next_step(location_x//100, location_y//100):
            # self.gc.flipover(mouseY//100, mouseX//100, self.color)
            # self.gc.delete_legal_space()
            self.gc.grid[location_x//100][location_y//100] = Disk(mouseX//100, mouseY//100, self.color)
            # self.change_color()
            # self.gc.check_legal_space(self.color)
            # self.gc.show_legal_space()

    def change_color(self):
        if self.color == 0:
            self.color = 255
        else:
            self.color = 0
        
