from game_controller import GameController
from board import Board


class Player:
    def __init__(self):
        self.player_turn = True
        

    def player_make_move(self):
        board = Board(DIMENSION, GRID_LEN)
        board.draw_disk(mouseY, mouseX)


    def computer_make_move(self):
        pass