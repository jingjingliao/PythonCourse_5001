class Disk:
    def __init__(self, column, row, color):
        self.column = column
        self.row = row
        self.color = color

    def draw_disk(self):
        fill(self.color)
        ellipse(self.column * 100 + 50, self.row * 100 + 50, 90, 90)

    def change_color(self, color):
        self.color = color
        self.draw_disk()
