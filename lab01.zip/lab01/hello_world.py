print("Hello World!")
print("Thanks for instructor and all TAs' help in my first lab class!")
print('I love coding!')
